import './App.css'
import { laptopService } from './Service/laptopService'
import {useState , useEffect} from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {

  const[laptop , setLaptop] = useState([])
  const [formData , setFormData] = useState({
    laptop_id: '',
    brand_name: '',
    model_name: '',
    serial_no: '',
    peripherals: ''
  })

  async function fetchData() {
    const data = await laptopService.getAll();
    setLaptop(data);
  }

  useEffect(() => {
    fetchData();
  },[handleDelete])

  function handleChange(e) {
    const {name , value} = e.target;
    setFormData({...formData , [name] : value})
  }

  //ADD
  function handleAdd() {
    laptopService.post(formData);
    fetchData();
  }

  //Update
  function handleUpdate() {
    laptopService.put(formData);
    fetchData();
  }

  //Delete
  function handleDelete(id) {
    laptopService.deleteRec(id);
    fetchData();
    console.log("Delete Clicked");
    
  }

  return (
    <>
      <h1>Welcome</h1>    
      <hr />

      <form className='form-control'>

      <label htmlFor="" className='form-label fw-bold'>Laptop ID</label>
        <input 
        type='text'
        placeholder='Enter Laptop Id'
        name='laptop_id'
        value={formData.laptop_id}
        className='form-control mb-3'
        onChange={handleChange}
        />

        <label htmlFor="" className='form-label fw-bold'>Brand Name</label>
        <input 
        type='text'
        placeholder='Enter Brand Name'
        name='brand_name'
        value={formData.brand_name}
        className='form-control mb-3'
        onChange={handleChange}
        required
        />

        <label htmlFor="" className='form-label fw-bold'>Model Name</label>
        <input 
        type='text'
        placeholder='Enter Model Name'
        name='model_name'
        value={formData.model_name}
        className='form-control mb-3'
        onChange={handleChange}
        required
        />

        <label htmlFor="" className='form-label fw-bold'>Serial No</label>
        <input 
        type='text'
        placeholder='Enter Serial No'
        name='serial_no'
        value={formData.serial_no}
        className='form-control mb-3'
        onChange={handleChange}
        required
        />

        <label htmlFor="" className='form-label fw-bold'>Peripherals</label>
        <input 
        type='text'
        placeholder='Enter Peripherals'
        name='peripherals'
        value={formData.peripherals}
        className='form-control mb-3'
        onChange={handleChange}
        required
        />

        <button className='btn btn-success m-3' onClick={handleAdd}> ADD </button>
        <button className='btn btn-warning m-3' onClick={handleUpdate}> UPDATE </button>
      </form>

    	<hr />

      {/*Card Component */}
      <div className='d-flex flex-wrap'>
        {
          laptop.map((rec) => (
            <div key={rec.laptop_id}>
              <div className='card bg-light m-3'>
                <h2 className='card-title text-primary'>{rec.brand_name}</h2>
                <p className='card-text fw-bold'>Model Name : {rec.model_name}</p>
                <p className='card-text fw-bold'>Serial No : {rec.serial_no}</p>
                <p className='card-text fw-bold'>Peripherals: {rec.peripherals}</p>
                <p className='card-text fw-bold text-success'>Laptop ID: {rec.laptop_id}</p>

                <button className='btn btn-danger' onClick={() => handleDelete(rec.laptop_id)}>Delete</button>
              </div>
            </div>
          ))
        }
      </div>
    </>
  )
}

export default App
