import axios from 'axios'

const API_URL = "http://localhost:1234/laptop"

export const laptopService = {
    getAll : async () => (await (axios.get(API_URL))).data,
    getById : async (id) => (await (axios.get(`${API_URL}/${id}`))).data,
    post : async (rec) => (await (axios.post(API_URL , rec))).data,
    put : async (rec) => (await (axios.put(`${API_URL}/${rec.id}` , rec))).data,
    deleteRec : async (id) => (await (axios.delete(`${API_URL}/${id}`))).data
}