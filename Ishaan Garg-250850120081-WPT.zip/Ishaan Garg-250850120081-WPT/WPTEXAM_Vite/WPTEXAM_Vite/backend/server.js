const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");

//MIDDLEWARE
const app = express();
app.use(express.json());
app.use(cors());

//Database Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'cdacacts',
    database: 'aptech_inventory'
})
db.connect((err) => {
    if(err) console.log("Error connecting to Database");
    else console.log("DataBase Connected Successfully");
})

//Queries
const getAll = "Select * from laptop_inventory";
const getById = "Select * from laptop_inventory where laptop_id = ?";
const post = "INSERT INTO laptop_inventory (brand_name, model_name, serial_no, peripherals) VALUES (?, ?, ?, ?)";
const put = "Update laptop_inventory set brand_name = ? , model_name = ? , serial_no = ? , peripherals = ? where laptop_id = ?";
const deleteRec = "Delete from laptop_inventory where laptop_id = ?";

//API's
app.get('/laptop' , (req , res) => {
    db.query(getAll , (err , result) => {
        if(err) return res.status(500).json({error : err.message});
        else return res.json(result);
    })
})

app.get('/laptop/:id' , (req , res) => {
    const {id} = req.params;
    db.query(getById , [id] , (err , result) => {
        if(err) return res.status(500).json({error : err.message});
        else return res.json(result);
    })
})

app.post('/laptop' , (req , res) => {
    const {brand_name, model_name, serial_no, peripherals} = req.body;
    db.query(post , [brand_name, model_name, serial_no, peripherals ] , (err , result) => {
        if(err) return res.status(500).json({error : err.message});
        else return res.json(result);
    })
})

app.put('/laptop/:id' , (req , res) => {
    const {laptop_id , brand_name, model_name, serial_no, peripherals} = req.body;
    db.query(put , [brand_name, model_name, serial_no, peripherals , laptop_id] , (err , result) => {
        if(err) return res.status(500).json({error : err.message});
        else return res.json({message : "Updated"});
    })
})

app.delete('/laptop/:id' , (req , res) => {
    const {id} = req.params;
    db.query(deleteRec , [id] , (err , result) => {
        if(err) return res.status(500).json({error : err.message});
        else return res.json({message : "Deleted"});
    })
})



app.listen(1234 , () => {
    console.log("Server is running on port 1234");
})