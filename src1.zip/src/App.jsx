

import './App.css'
import Calculatorlogic from './components/Calculatorlogic'
function App() {
  return (
    <>
      <Calculatorlogic/>
    </>
  )
}

export default App
