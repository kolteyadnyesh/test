
import React, { useState } from "react";

function calculatorlogic(){
    const [first, setFirst] = useState(0);
    const [operand, setOperand] = useState("+")
    const [second, setSecond] = useState(0);
    const [result, setResult] = useState(0);
    
    const getResult = () =>  {
        switch(operand){
            case '+':
                setOperand(first+second);
                break;
            case '-':
                setOperand(first-second);
                break;
            case '*':
                setOperand(first*second);
                break;
            case '/':
                setOperand(first/second)
                break;
            default:
                alert("Invalid Operator");
                break;
        }
    }
    return(
        <>
            <h1>Calculator App</h1>
            <hr />
            <input placeholder="1st number" name="num1" value={first}></input>
            <select value={operand}>
                <option>+</option>
                <option>-</option>
                <option>*</option>
                <option>/</option>
            </select>
            <input placeholder="2nd number" name="num2" value={second}></input>
            <p>=</p>
            <button placeholder= "Calculate"style={{backgroundColor: "red"}}></button>
            <span>{result}</span>

        </>
    )
}

export default calculatorlogic;