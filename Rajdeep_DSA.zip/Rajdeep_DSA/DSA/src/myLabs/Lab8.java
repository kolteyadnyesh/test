package myLabs;

//8. Find the Sum of Numbers from 1 to N 

public class Lab8 {

	public static void main(String[] args) {
	
		int n=5;
		
		int sum = 0;
		for(int i =1;i<=n;i++) {
			sum = sum+i;
		}
		System.out.println("Sum : "+sum); 
	}

}
