package myLabs;

//14. Count the Divisibles of given Number

public class Lab19 {
	public static void main(String[] args) { 
	 int n = 10;

	 int count = 2;
	 for (int i = 2; i <= n/2; i++) {
	 if (n % i == 0)
	 count++;
	 }
	 System.out.println("Count : "+ count);
	 }
}
	// Time Complexity - O(n/2)
	//Space Complexity - O(1) 
