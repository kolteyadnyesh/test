package myLabs;

//12. Print the Divisibles of 6 from 1 to N 

public class Lab12 {

	public static void main(String[] args) {
		
		int n=25;
		for(int i=1;i<=n;i++) {
			if(i%6==0) {
				System.out.println(i);
			}
		}
	}

}
