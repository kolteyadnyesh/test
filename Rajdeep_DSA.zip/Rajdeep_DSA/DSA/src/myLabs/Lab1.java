package myLabs;

//1. Swap 2 Numbers

public class Lab1 {

	public static void main(String[] args) {

		int a =10;
		int b= 20;
		System.out.println(a+ "\t" +b);
		
		int temp=a;
		a=b;
		b=temp;
		System.out.println(a+ "\t" +b);
		
	}

}
