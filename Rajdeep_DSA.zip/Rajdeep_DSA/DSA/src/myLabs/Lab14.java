package myLabs;

//14. Find the Sum of Divisibles of given Number(exclude N)

public class Lab14 {

	public static void main(String[] args) {
		
		int n =30;
		
		int sum=0;
		for(int i=1;i<=n/2;i++) {
			if(n%i==0)
				sum+=i;
		}
		System.out.println("Sum : "+ sum); 

	}

}
