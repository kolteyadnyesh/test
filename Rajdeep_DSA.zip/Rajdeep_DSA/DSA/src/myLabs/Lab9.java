package myLabs;

//9. Find the Sum of Numbers from 1 to N 

public class Lab9 {

	public static void main(String[] args) {
		
		int n =5;
		
		int sum = n*(n+1)/2;
		System.out.println("Sum : "+sum);

	}

}
