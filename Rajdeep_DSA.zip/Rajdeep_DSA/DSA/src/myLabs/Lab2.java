package myLabs;

//2. Swap 2 Numbers without 3rd Variable

public class Lab2 {
	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		
		System.out.println(a+"\t"+b);
		
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println(a+"\t"+b);
		
		
	}

}
