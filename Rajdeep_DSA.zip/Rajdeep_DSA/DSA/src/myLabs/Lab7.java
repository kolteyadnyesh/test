package myLabs;

//7. Print the Even Numbers from 1 to N

public class Lab7 {

	public static void main(String[] args) {
	
		
		int n=50;
		
		for(int i=0;i<=n;i++) {
		if(i%2==0) {
			System.out.println("even num - " + i);
		}
		}
			

	}

}
