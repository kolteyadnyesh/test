package myLabs;

//20. Check whether given nymber is Perfect Number or not

public class Lab20 {

	public static boolean isPerfect(int n) {
		 int sum = 0;
		 for (int i = 1; i <= n / 2; i++) {
		 if (n % i == 0)
		 sum += i;
		 }

		 if (sum == n)
		 return true;
		 else
		 return false;
		 }
		 public static void main(String[] args) {
		 int n = 60;
		 boolean flag = isPerfect(n);
		 System.out.println(flag);
		 } 

}
