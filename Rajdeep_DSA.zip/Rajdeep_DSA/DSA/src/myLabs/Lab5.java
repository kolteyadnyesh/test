package myLabs;

//5. Find min & max of 3 Numbers

public class Lab5 {
	
		public static void main(String[] args) {

			int a=10;
			int b=16;
			int c=20;
			
			int min=(a<b)?((a<c)?a:c):((b<c)?b:c);
			System.out.println(min);
			System.out.println("Min value is:" +min);
			
			int max=(a>b)?((a>c)?a:c):((b>c)?b:c);
			System.out.println(max);
			
		
			if(a>b && a>c) {
				max=a;
			}else if (b>a && b>c) {
				max=b;
			}else{
			System.out.println("Max value is:" +max);
			}
		}
}

