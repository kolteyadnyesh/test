package myLabs;

//15. Check whether Given Number is Prime or Not 

public class Lab15 {
	
	public static boolean isPrime(int n) {
		int count=0;
		for(int i=2;i<=n/2;i++) {
			if(n%i==0)
				count++;
			
		}
		if(count==0)
			return true;
		else
			return false;
	}
	public static void main(String[] args) {
		int n=2;
		boolean flag = isPrime(n);
		System.out.println(flag);
		
	}

}

