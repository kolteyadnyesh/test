package myLabs;

//3. Swap 2 Strings 

public class Lab3 {

	public static void main(String[] args) {

		String str1="Rajat";
		String str2="Raju";
		System.out.println(str1+"\t"+str2); 

		String temp=str1;
		str1=str2;
		str2=temp;
		System.out.println(str1+"\t"+str2); 

		
	}

}
