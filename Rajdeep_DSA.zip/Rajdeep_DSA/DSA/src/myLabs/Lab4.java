package myLabs;

//4. Find min & max of 2 Numbers

public class Lab4 {

	public static void main(String[] args) {

		int a=10;
		int b=20;
		
		int min=(a<b)?a:b;
		System.out.println("Min value is: "+ min);
		
		int max=0;
		if(a>b) {
			max=a;
		}else {
			max=b;
		}
		System.out.println("Max value is: "+ max);
		
	}

}
